jQuery.sap.require("api.app.vaccineSlot.util.formatter");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller,JSONModel) {
	"use strict";

	return Controller.extend("api.app.vaccineSlot.controller.Home", {
		onInit: function () {
			// Setting Model to Homepage Drop Down List
			var oJsonModel = new JSONModel("model/listData.json",null,false);
			this.getView().setModel(oJsonModel);
			this.setChartProps();
		},
		
		onButtonPress: function(oEvent) {
	 		var oButton = oEvent.getSource();
			this.byId("actionSheet").openBy(oButton);
				
		},
		
		handleNav:function(oEvent,id){
			var navCon = this.byId("navCon");
			var target = oEvent.getSource().data("target");
			if (target) {
				navCon.to(this.byId(target));
			} else {
				navCon.back();
			}
		},
		homeButtonPress : function(oEvent){
			this.handleNav(oEvent, "Home");
		},
		
		pincodeGo : function(){
		var sPinCode = this.getView().byId("idPinCodeInput").getValue();
		var sSelectedDate = this.dateConversion(this.getView().byId("idPinCodeDatePicker").getDateValue());
		var sPath = "https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/findByPin?pincode=" + sPinCode + "&date=" + sSelectedDate;
		var oPinModel = new sap.ui.model.json.JSONModel(sPath);
		this.getView().setModel(oPinModel,"oPinModel");
		
		
		},
		dateConversion: function(d){
		//	var sDate = that.getView().byId("Date1").getDateValue();
				var today = new Date(d);
				today.setDate(today.getDate());
				var dd = today.getDate();
				var mm = today.getMonth() + 1;
				var yyyy = today.getFullYear();
				if (dd < 10) {
					dd = '0' + dd;
				}
				if (mm < 10) {
					mm = '0' + mm;
				}
				var today = dd + '-' + mm + '-' + yyyy;

				return today;
			
		},
		
		setChartProps: function(){
			//      1.Get the id of the VizFrame
			var oVizFrame = this.getView().byId("idpiechart");

			if (sap.ui.Device.system.phone) {
				oVizFrame.setHeight("400px");
				oVizFrame.setWidth("400px");
			}

			//      2.Create a JSON Model and set the data
			var sCountryUrl = "https://coronavirus-19-api.herokuapp.com/countries";
			var oModel = new sap.ui.model.json.JSONModel(sCountryUrl);
			// oModel.setData(data);
			//  3. Create Viz dataset to feed to the data to the graph
			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: 'country',
					value: "{country}"
				}],

				measures: [{
					name: 'cases',
					value: '{cases}'
				}],

				data: {
					path: "/"
				}
			});

			oVizFrame.setDataset(oDataset);
			oVizFrame.setModel(oModel);

			//      4.Set Viz properties with dynamic
			oVizFrame.setVizProperties({
				title: {
					text: "Vaccination Chart India"
				},
				plotArea: {
					colorPalette: d3.scale.category20().range(),
					drawingEffect: "normal"
				}
			});

			var feedSize = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "size",
				'type': "Measure",
				'values': ["cases"]
			}),
				feedColor = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "color",
					'type': "Dimension",
					'values': ["country"]
				});
			oVizFrame.addFeed(feedSize);
			oVizFrame.addFeed(feedColor);

		}
	});
});