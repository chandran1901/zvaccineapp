/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"api/app/vaccineSlot/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});