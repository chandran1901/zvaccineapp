sap.ui.define([
	"api/app/vaccineSlot/test/unit/controller/Home.controller"
], function () {
	"use strict";
});