	jQuery.sap.declare("api.app.vaccineSlot.util.formatter");

	api.app.vaccineSlot.util.formatter = {
		CLIpincode : function(availability){
			if(availability === 0){
					this.removeStyleClass("clsCLIpincode");
				this.addStyleClass("noAvailableCLI");
				
				
			}
			else{
				this.removeStyleClass("noAvailableCLI");
				this.addStyleClass("clsCLIpincode");
			}
			return true;
		}
		
		
	};